<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  echo "Unauthorized access.";
  exit();
}

require_once __DIR__ . '/../../database/database.class.php';
$conn = (new Database())->connect();

// Handle AJAX delete request for events
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax']) && $_POST['ajax'] === 'delete_event') {
  $event_id = $_POST['event_id'];

  $query = $conn->prepare("DELETE FROM events WHERE event_id = :event_id");
  $query->bindParam(':event_id', $event_id);
  if ($query->execute()) {
    echo json_encode(['success' => true]);
  } else {
    echo json_encode(['success' => false, 'error' => 'Unable to delete event.']);
  }
  exit();
}

// Handle new event addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_event'])) {
  $event_name = $_POST['event_name'];
  $event_date = $_POST['event_date'];

  $query = $conn->prepare("INSERT INTO events (event_name, event_date) VALUES (:event_name, :event_date)");
  $query->bindParam(':event_name', $event_name);
  $query->bindParam(':event_date', $event_date);

  if ($query->execute()) {
    header("Location: index.php?message=Event added successfully");
    exit();
  } else {
    $error_message = "Failed to add event.";
  }
}

// Fetch all events
$query = $conn->prepare("SELECT * FROM events");
$query->execute();
$events = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
  <div class="container mt-5">
    <h2>Event Management</h2>
    <div class="mb-3">
      <input type="text" id="search_event_bar" class="form-control" placeholder="Search for events..." onkeyup="searchEvent()">
      <select id="date_filter" class="form-select mt-2" onchange="filterEventsByDate()">
        <option value="">All Dates</option>
        <!-- Additional date options can be added here -->
      </select>
    </div>
    <table class="table table-bordered" id="events_table">
      <thead>
        <tr>
          <th>Event</th>
          <th>Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($events as $event): ?>
          <tr id="event-row-<?= $event['event_id'] ?>">
            <td><?= htmlspecialchars($event['event_name']) ?></td>
            <td><?= htmlspecialchars($event['event_date']) ?></td>
            <td>
              <button class="btn btn-warning btn-sm" onclick="editEvent(<?= $event['event_id'] ?>)">Edit</button>
              <button class="btn btn-danger btn-sm" onclick="deleteEvent(<?= $event['event_id'] ?>)">Delete</button>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <h3>Add New Event</h3>
    <form action="index.php" method="post">
      <div class="mb-3">
        <label for="event_name" class="form-label">Event Name</label>
        <input type="text" id="event_name" name="event_name" class="form-control" required>
      </div>
      <div class="mb-3">
        <label for="event_date" class="form-label">Event Date</label>
        <input type="date" id="event_date" name="event_date" class="form-control" required>
      </div>
      <button type="submit" name="add_event" class="btn btn-primary">Add Event</button>
    </form>
  </div>

  <script>
    function searchEvent() {
      const input = document.getElementById("search_event_bar").value.toUpperCase();
      const table = document.getElementById("events_table");
      const rows = table.getElementsByTagName("tr");

      for (let i = 1; i < rows.length; i++) {
        const eventNameCell = rows[i].getElementsByTagName("td")[0];
        const eventName = eventNameCell ? eventNameCell.textContent || eventNameCell.innerText : "";
        rows[i].style.display = eventName.toUpperCase().includes(input) ? "" : "none";
      }
    }

    function filterEventsByDate() {
      const filter = document.getElementById("date_filter").value;
      const table = document.getElementById("events_table");
      const rows = table.getElementsByTagName("tr");

      for (let i = 1; i < rows.length; i++) {
        const dateCell = rows[i].getElementsByTagName("td")[1];
        const eventDate = dateCell ? dateCell.textContent || dateCell.innerText : "";
        rows[i].style.display = filter === "" || eventDate.includes(filter) ? "" : "none";
      }
    }

    function deleteEvent(eventId) {
      showConfirmationModal("Are you sure you want to delete this event?", () => {
        fetch("index.php", {
            method: "POST",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              ajax: "delete_event",
              event_id: eventId
            })
          })
          .then(response => response.json())
          .then(data => {
            if (data.success) {
              document.getElementById(`event-row-${eventId}`).remove();
            } else {
              alert("Error: " + (data.error || "Unable to delete event."));
            }
          })
          .catch(err => console.error("AJAX error:", err));
      });
    }

    function editEvent(eventId) {
      window.location.href = `edit_event_admin.php?event_id=${eventId}`;
    }
  </script>

  <?php include '../MAIN/auth/loads/confirmation.php'; ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>