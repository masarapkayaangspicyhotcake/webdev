
<div id="sports_section" class="dashboard-section" >
        <h2>Available Sports</h2>
        <table>
            <thead>
                <tr>
                    <th>Sport Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($sports as $sport): ?>
                    <tr>
                        <td><?= $sport['sport_name'] ?></td>
                        <td>
                            <button onclick="showRegistrationForm(<?= $sport['sport_id'] ?>)">Register</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div id="registration_form" style="display:none;">
            <h3>Register for Sport</h3>
            <form action="student_dashboard.php" method="post">
                <input type="hidden" id="sport_id" name="sport_id">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" required>
                <label for="sex">Sex</label>
                <select id="sex" name="sex" required>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
                <label for="course">Course</label>
                <select id="course" name="course" onchange="updateSections()" required>
                    <option value="CS">CS</option>
                    <option value="IT">IT</option>
                    <option value="ACT">ACT</option>
                    <?php foreach ($courses as $course): ?>
                        <option value="<?= $course['course_id'] ?>"><?= $course['course_name'] ?></option>
                    <?php endforeach; ?>
                </select>
                <label for="section">Section</label>
                <select id="section" name="section" required>
                    <option value="CS2">CS2</option>
                    <!-- Section options will be populated based on the selected course -->
                </select>
                <button type="submit" name="register_sport">Submit</button>
            </form>
        </div>
    </div>