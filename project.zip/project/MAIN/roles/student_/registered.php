<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            // Fetch data from the server using AJAX
            function fetchRegisteredSports() {
                fetch('get_registrations.php')
                    .then(response => {
                        if (!response.ok) {
                            throw new Error("Network response was not ok");
                        }
                        return response.json();
                    })
                    .then(data => {
                        const tbody = document.querySelector('#registered_sports_section tbody');
                        tbody.innerHTML = ""; // Clear existing content

                        // Populate table with new data
                        if (data.length > 0) {
                            data.forEach(registration => {
                                const row = `
                                    <tr>
                                        <td>${registration.sport_name}</td>
                                        <td>${registration.status.charAt(0).toUpperCase() + registration.status.slice(1)}</td>
                                    </tr>
                                `;
                                tbody.innerHTML += row;
                            });
                        } else {
                            tbody.innerHTML = '<tr><td colspan="2">No registered sports found.</td></tr>';
                        }
                    })
                    .catch(error => {
                        console.error("Error fetching data:", error);
                        document.querySelector('#registered_sports_section tbody').innerHTML = '<tr><td colspan="2">Failed to load data.</td></tr>';
                    });
            }

            // Fetch data on page load
            fetchRegisteredSports();
        });
    </script>
</head>
<body>
    <div id="registered_sports_section" class="dashboard-section">
        <h2>Registered Sports</h2>
        <table>
            <thead>
                <tr>
                    <th>Sport</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr><td colspan="2">Loading...</td></tr>
            </tbody>
        </table>
    </div>
</body>
</html>
