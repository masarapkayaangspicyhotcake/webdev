
<div id="events_section" class="dashboard-section">
  <h2>Upcoming Events</h2>
  <table class="table">
    <thead>
      <tr>
        <th>Event Name</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody id="events_table_body">
      <!-- Events will be dynamically populated here -->
    </tbody>
  </table>
</div>
