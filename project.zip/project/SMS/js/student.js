//  function updateSections() {
//      var courseId = document.getElementById('course').value;
//      var sectionSelect = document.getElementById('section');
//      sectionSelect.innerHTML = '';

//      var sections = <?php echo json_encode($sections); ?>;
//      for (var i = 0; i < sections.length; i++) {
//          if (sections[i].course_id == courseId) {
//              var option = document.createElement('option');
//              option.value = sections[i].section_name;
//              option.text = sections[i].section_name;
//              sectionSelect.appendChild(option);
//          }
//      }

//      if (sectionSelect.options.length == 0) {
//          var option = document.createElement('option');
//          option.value = '';
//          option.text = 'N/A';
//          sectionSelect.appendChild(option);
//      }
//  }

 function showRegistrationForm(sport_id) {
     document.getElementById('sport_id').value = sport_id;
     document.getElementById('registration_form').style.display = 'block';
 }

 function showSection(sectionId) {
     var sections = document.getElementsByClassName('dashboard-section');
     for (var i = 0; i < sections.length; i++) {
         sections[i].style.display = 'none';
     }
     document.getElementById(sectionId).style.display = 'block';
}



